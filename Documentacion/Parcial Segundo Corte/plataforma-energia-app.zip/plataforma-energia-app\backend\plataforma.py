"""
Plataforma de Comercio de Energía — lógica de dominio (patrón Singleton).
Este módulo es consumido por main.py (API FastAPI).
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict, replace
from datetime import datetime
from statistics import mean
from threading import Lock
from typing import Optional
import copy
import itertools
import random

from catalogo_dispositivos import fabrica_fichas
from factory_method import DispositivoIoT, crear_dispositivo
from jerarquia import DispositivoHoja, GrupoEnergetico
from notificaciones import Mensaje, crear_servicio, obtener_canal
from pagos import obtener_pasarela
from precios import CostoBase, CostoEnergia, aplicar_ajustes
from reportes import DatosReporte, DirectorReportes, crear_builder
from sincronizacion import SincronizadorConReintentos, SincronizadorDispositivo, obtener_protocolo

# Política de precios (patrón Decorator): franja de hora pico y número de
# compras previas a partir del cual un comprador se considera frecuente.
HORA_PICO = range(18, 21)  # 18:00 a 20:59
COMPRAS_COMPRADOR_FRECUENTE = 3


class SingletonMeta(type):
    """Metaclase que garantiza una única instancia, segura ante concurrencia."""
    _instances: dict[type, object] = {}
    _lock: Lock = Lock()

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            with cls._lock:
                if cls not in cls._instances:
                    cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]


@dataclass
class Usuario:
    id: str
    nombre: str
    password_hash: str = ""
    balance_kwh: float = 0.0
    canal_notificacion: str = "email"  # "email" | "sms" | "push"
    email: str = ""
    telefono: str = ""
    pasarela_pago: str = "stripe"  # "stripe" | "payu"

    def to_dict(self):
        return {
            "id": self.id,
            "nombre": self.nombre,
            "balance_kwh": self.balance_kwh,
            "canal_notificacion": self.canal_notificacion,
            "email": self.email,
            "telefono": self.telefono,
            "pasarela_pago": self.pasarela_pago,
        }

    def destino_para(self, canal: str) -> str:
        """Dirección concreta a la que sale una notificación por ese canal."""
        if canal == "email":
            return self.email
        if canal == "sms":
            return self.telefono
        return self.id  # push: token/identificador del dispositivo


@dataclass
class Orden:
    id: int
    usuario_id: str
    tipo: str
    cantidad_kwh: float
    precio_kwh: float
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self):
        d = asdict(self)
        d["timestamp"] = self.timestamp.isoformat()
        return d


class PlataformaEnergia(metaclass=SingletonMeta):
    """Punto único de acceso al sistema de comercio de energía."""

    def __init__(self):
        self.usuarios: dict[str, Usuario] = {}
        self.dispositivos: dict[str, DispositivoIoT] = {}
        self.ordenes_venta: list[Orden] = []
        self.ordenes_compra: list[Orden] = []
        self.historial_transacciones: list[dict] = []
        self.lecturas_iot: dict[str, list[float]] = {}
        # Bandeja de notificaciones por usuario (patrón Abstract Factory).
        self.notificaciones: dict[str, list[dict]] = {}
        # Bandeja de pagos por usuario (patrón Adapter).
        self.pagos: dict[str, list[dict]] = {}
        self._contador_ordenes = itertools.count(1)

    def registrar_usuario(
        self,
        id_: str,
        nombre: str,
        password_hash: str = "",
        canal_notificacion: str = "email",
        email: str = "",
        telefono: str = "",
        pasarela_pago: str = "stripe",
    ) -> Usuario:
        obtener_canal(canal_notificacion)  # valida el canal antes de crear el usuario
        obtener_pasarela(pasarela_pago)  # valida la pasarela antes de crear el usuario
        return self.usuarios.setdefault(
            id_,
            Usuario(
                id_,
                nombre,
                password_hash,
                canal_notificacion=canal_notificacion,
                email=email,
                telefono=telefono,
                pasarela_pago=pasarela_pago,
            ),
        )

    def actualizar_contacto(
        self, usuario_id: str, email: Optional[str] = None, telefono: Optional[str] = None
    ) -> Usuario:
        usuario = self.usuarios[usuario_id]
        if email is not None:
            usuario.email = email
        if telefono is not None:
            usuario.telefono = telefono
        return usuario

    # ---------- Notificaciones (patrón Abstract Factory) ----------
    def _servicio_notificaciones(self, usuario_id: str):
        """
        Construye el servicio de notificaciones para un usuario ELIGIENDO la
        fábrica abstracta según su canal preferido. El resto de la plataforma
        no conoce ninguna clase concreta de notificador.
        """
        usuario = self.usuarios.get(usuario_id)
        canal = usuario.canal_notificacion if usuario else "email"
        return crear_servicio(canal)

    def _guardar_notificacion(self, usuario_id: str, mensaje: Mensaje) -> dict:
        usuario = self.usuarios.get(usuario_id)
        if usuario is not None and not mensaje.destino:
            mensaje = replace(mensaje, destino=usuario.destino_para(mensaje.canal))
        registro = mensaje.to_dict()
        registro["timestamp"] = datetime.now().isoformat()
        self.notificaciones.setdefault(usuario_id, []).append(registro)
        return registro

    def cambiar_canal_notificacion(self, usuario_id: str, canal: str) -> Usuario:
        obtener_canal(canal)  # ValueError si no existe
        usuario = self.usuarios[usuario_id]
        usuario.canal_notificacion = canal
        return usuario

    def bandeja_notificaciones(self, usuario_id: str) -> list[dict]:
        return list(self.notificaciones.get(usuario_id, []))

    # ---------- Cobro de transacciones (patrón Adapter) ----------
    def cambiar_pasarela_pago(self, usuario_id: str, pasarela: str) -> Usuario:
        obtener_pasarela(pasarela)  # ValueError si no existe
        usuario = self.usuarios[usuario_id]
        usuario.pasarela_pago = pasarela
        return usuario

    def _cobrar_transaccion(self, tx: dict) -> dict:
        """
        Cobra el total de la transacción al comprador usando SU pasarela de
        pago preferida (patrón Adapter): la plataforma solo conoce la
        interfaz PasarelaPago, nunca el SDK concreto de Stripe ni de PayU.
        """
        comprador = self.usuarios.get(tx["comprador"])
        nombre_pasarela = comprador.pasarela_pago if comprador else "stripe"
        resultado = obtener_pasarela(nombre_pasarela).procesar_pago(
            tx["comprador"], tx["total"], f"Compra de {tx['cantidad_kwh']} kWh"
        )
        registro = asdict(resultado)
        self.pagos.setdefault(tx["comprador"], []).append(registro)
        return registro

    def bandeja_pagos(self, usuario_id: str) -> list[dict]:
        return list(self.pagos.get(usuario_id, []))

    # ---------- Precio final de la transacción (patrón Decorator) ----------
    def _ajustes_para(self, comprador: str, vendedor: str, momento: datetime) -> list[str]:
        """
        Decide QUÉ capas aplicar a una transacción y en qué orden: primero
        los descuentos, luego los recargos, luego el cargo fijo y al final la
        comisión de la plataforma. Cómo se calcula cada capa lo resuelve su
        decorador en precios.py.
        """
        ajustes = []
        if any(d.usuario_id == vendedor and d.tipo == "panel_solar" for d in self.dispositivos.values()):
            ajustes.append("renovable")
        compras_previas = sum(1 for tx in self.historial_transacciones if tx["comprador"] == comprador)
        if compras_previas >= COMPRAS_COMPRADOR_FRECUENTE:
            ajustes.append("frecuente")
        if momento.hour in HORA_PICO:
            ajustes.append("hora_pico")
        ajustes += ["uso_red", "comision"]
        return ajustes

    def _calcular_costo(
        self, cantidad_kwh: float, precio_kwh: float, comprador: str, vendedor: str, momento: datetime
    ) -> CostoEnergia:
        """Envuelve el costo base con las capas que le corresponden (Decorator)."""
        return aplicar_ajustes(
            CostoBase(cantidad_kwh, precio_kwh), self._ajustes_para(comprador, vendedor, momento)
        )

    def cotizar(self, cantidad_kwh: float, precio_kwh: float, ajustes: list[str]) -> dict:
        """Simula el precio con los ajustes elegidos, en el orden elegido."""
        base = CostoBase(cantidad_kwh, precio_kwh)
        costo = aplicar_ajustes(base, ajustes)
        return {"subtotal": base.total(), "total": costo.total(), "desglose": costo.desglose()}

    # ---------- Árbol energético de la comunidad (patrón Composite) ----------
    def arbol_energetico(self) -> GrupoEnergetico:
        """
        Arma el árbol Comunidad → Hogar (un usuario) → Dispositivo (hoja) con el
        estado actual del Singleton. Producción, consumo y balance de cualquier
        nivel se obtienen con la misma llamada: cada grupo delega en sus hijos.
        """
        comunidad = GrupoEnergetico("Comunidad Voltia", "comunidad")
        hogares: dict[str, GrupoEnergetico] = {}
        for usuario in self.usuarios.values():
            hogares[usuario.id] = GrupoEnergetico(f"Hogar de {usuario.nombre}", "hogar")
            comunidad.agregar(hogares[usuario.id])
        for disp in self.dispositivos.values():
            hogar = hogares.get(disp.usuario_id)
            if hogar is not None:
                hogar.agregar(DispositivoHoja(disp.id, disp.tipo, self.lecturas_iot.get(disp.id, [])))
        return comunidad

    # ---------- Reporte energético (patrón Builder) ----------
    def _recolectar_datos_reporte(self, usuario_id: str) -> DatosReporte:
        """
        Reúne la materia prima del reporte desde el estado del Singleton. El
        builder solo le da forma; aquí no se decide ni el formato ni las
        secciones.
        """
        produccion = consumo = 0.0
        lecturas_por_dispositivo: dict[str, list[float]] = {}
        prediccion_por_dispositivo: dict[str, float | None] = {}
        for disp in self.dispositivos.values():
            if disp.usuario_id != usuario_id:
                continue
            lecturas = list(self.lecturas_iot.get(disp.id, []))
            lecturas_por_dispositivo[disp.id] = lecturas
            prediccion_por_dispositivo[disp.id] = self.predecir_siguiente_valor(disp.id)
            for lectura in lecturas:
                if lectura >= 0:
                    produccion += lectura
                else:
                    consumo += -lectura
        transacciones = [
            tx
            for tx in self.historial_transacciones
            if usuario_id in (tx["comprador"], tx["vendedor"])
        ]
        return DatosReporte(
            usuario=usuario_id,
            periodo=datetime.now().strftime("%Y-%m"),
            produccion_kwh=round(produccion, 2),
            consumo_kwh=round(consumo, 2),
            lecturas_por_dispositivo=lecturas_por_dispositivo,
            transacciones=transacciones,
            prediccion_por_dispositivo=prediccion_por_dispositivo,
        )

    def generar_reporte(self, usuario_id: str, formato: str = "detallado") -> dict:
        """
        Construye el reporte energético del usuario PASO A PASO (patrón Builder)
        en el formato pedido, y además deja el resumen en su bandeja por su
        canal (patrón Abstract Factory).
        """
        datos = self._recolectar_datos_reporte(usuario_id)

        # 1) El reporte que se devuelve, en la representación elegida.
        director = DirectorReportes(crear_builder(formato))
        reporte = director.reporte_completo(datos)

        # 2) El aviso por el canal del usuario: el builder "resumen" produce el
        #    dict plano que espera el FormateadorReporte del Abstract Factory.
        director.builder = crear_builder("resumen")
        resumen = director.reporte_ejecutivo(datos)
        mensaje = self._servicio_notificaciones(usuario_id).enviar_reporte(resumen)
        registro = self._guardar_notificacion(usuario_id, mensaje)

        return {
            "formato": formato,
            "reporte": reporte.to_dict() if hasattr(reporte, "to_dict") else reporte,
            "notificacion": registro,
        }

    def publicar_venta(self, usuario_id: str, cantidad_kwh: float, precio_kwh: float) -> Orden:
        orden = Orden(next(self._contador_ordenes), usuario_id, "venta", cantidad_kwh, precio_kwh)
        self.ordenes_venta.append(orden)
        return orden

    def publicar_compra(self, usuario_id: str, cantidad_kwh: float, precio_kwh: float) -> Orden:
        orden = Orden(next(self._contador_ordenes), usuario_id, "compra", cantidad_kwh, precio_kwh)
        self.ordenes_compra.append(orden)
        return orden

    def ejecutar_subasta(self) -> list[dict]:
        self.ordenes_venta.sort(key=lambda o: o.precio_kwh)
        self.ordenes_compra.sort(key=lambda o: -o.precio_kwh)

        transacciones = []
        for compra in list(self.ordenes_compra):
            for venta in list(self.ordenes_venta):
                if compra.precio_kwh >= venta.precio_kwh and compra.cantidad_kwh > 0 and venta.cantidad_kwh > 0:
                    cantidad = min(compra.cantidad_kwh, venta.cantidad_kwh)
                    precio_final = venta.precio_kwh
                    compra.cantidad_kwh -= cantidad
                    venta.cantidad_kwh -= cantidad

                    # Precio final = costo base + capas de ajuste (Decorator).
                    momento = datetime.now()
                    costo = self._calcular_costo(
                        cantidad, precio_final, compra.usuario_id, venta.usuario_id, momento
                    )
                    tx = {
                        "comprador": compra.usuario_id,
                        "vendedor": venta.usuario_id,
                        "cantidad_kwh": cantidad,
                        "precio_kwh": precio_final,
                        "subtotal": round(cantidad * precio_final, 2),
                        "total": costo.total(),
                        "ajustes": costo.desglose()[1:],
                        "timestamp": momento.isoformat(),
                    }
                    transacciones.append(tx)
                    self.historial_transacciones.append(tx)

                    # Cobro al comprador por SU pasarela (Adapter).
                    tx["pago"] = self._cobrar_transaccion(tx)

                    # Aviso a las dos partes por SU canal (Abstract Factory).
                    for usuario_id, rol in ((tx["comprador"], "comprador"), (tx["vendedor"], "vendedor")):
                        mensaje = self._servicio_notificaciones(usuario_id).avisar_puja_ganada(
                            tx, destinatario=usuario_id, rol=rol
                        )
                        self._guardar_notificacion(usuario_id, mensaje)

                    if compra.cantidad_kwh == 0:
                        break

        self.ordenes_venta = [o for o in self.ordenes_venta if o.cantidad_kwh > 0]
        self.ordenes_compra = [o for o in self.ordenes_compra if o.cantidad_kwh > 0]
        return transacciones

    def conectar_dispositivo(
        self,
        id_dispositivo: str,
        usuario_id: str,
        tipo: str,
        umbral_min: Optional[float] = None,
        umbral_max: Optional[float] = None,
    ) -> DispositivoIoT:
        """
        Da de alta un dispositivo IoT resolviendo su fábrica concreta según
        el tipo (patrón Factory Method): la plataforma nunca decide con un
        if/elif qué clase instanciar ni qué umbrales por defecto aplicar.
        """
        dispositivo = crear_dispositivo(tipo, id_dispositivo, usuario_id, umbral_min, umbral_max)
        self.dispositivos[id_dispositivo] = dispositivo
        self.lecturas_iot.setdefault(id_dispositivo, [])
        return dispositivo

    # ---------- Alta por clonación (patrón Prototype) ----------
    def clonar_dispositivo(
        self,
        dispositivo_id: str,
        nuevo_id: str,
        usuario_id: str,
        umbral_min: Optional[float] = None,
        umbral_max: Optional[float] = None,
    ) -> DispositivoIoT:
        """
        Da de alta un dispositivo nuevo CLONANDO uno ya calibrado, en vez de
        crearlo desde cero con los umbrales por defecto del tipo
        (`UMBRALES_IOT`). Útil para instalaciones con varios dispositivos
        idénticos (mismo tipo y mismos umbrales ajustados en campo): el
        operador no repite esos números a mano en cada alta.
        """
        original = self.dispositivos.get(dispositivo_id)
        if original is None:
            raise ValueError(f"Dispositivo {dispositivo_id} no está registrado")
        if nuevo_id in self.dispositivos:
            raise ValueError(f"Dispositivo {nuevo_id} ya existe")

        clon = copy.deepcopy(original)
        clon.id = nuevo_id
        clon.usuario_id = usuario_id
        if umbral_min is not None:
            clon.umbral_min = umbral_min
        if umbral_max is not None:
            clon.umbral_max = umbral_max

        self.dispositivos[nuevo_id] = clon
        self.lecturas_iot.setdefault(nuevo_id, [])
        return clon

    def enviar_lectura_iot(self, id_dispositivo: str, valor_kwh: float) -> None:
        if id_dispositivo not in self.dispositivos:
            raise ValueError(f"Dispositivo {id_dispositivo} no está registrado")
        self.lecturas_iot[id_dispositivo].append(valor_kwh)

        dispositivo = self.dispositivos[id_dispositivo]
        umbral = dispositivo.fuera_de_rango(valor_kwh)
        if umbral is not None:
            mensaje = self._servicio_notificaciones(dispositivo.usuario_id).avisar_alerta_iot(
                id_dispositivo, dispositivo.tipo, valor_kwh, umbral
            )
            self._guardar_notificacion(dispositivo.usuario_id, mensaje)

    def simular_lecturas(self, id_dispositivo: str, n: int = 5) -> None:
        for _ in range(n):
            self.enviar_lectura_iot(id_dispositivo, round(random.uniform(0.5, 4.0), 2))

    # ---------- Sincronización por protocolo (patrón Bridge) ----------
    def sincronizar_dispositivo(
        self, id_dispositivo: str, protocolo: str = "simulado", con_reintentos: bool = False
    ) -> float:
        """
        Obtiene una lectura nueva usando el protocolo de comunicación
        elegido (simulado/HTTP/MQTT) sin que el resto de la plataforma
        conozca esa clase concreta, y la registra igual que cualquier otra
        lectura (umbrales, alertas). `con_reintentos` envuelve la misma
        Abstraction con la RefinedAbstraction que reintenta ante fallas.
        """
        if id_dispositivo not in self.dispositivos:
            raise ValueError(f"Dispositivo {id_dispositivo} no está registrado")
        dispositivo = self.dispositivos[id_dispositivo]
        ultima = self.lecturas_iot[id_dispositivo][-1] if self.lecturas_iot[id_dispositivo] else None

        impl = obtener_protocolo(protocolo)
        sincronizador = SincronizadorConReintentos(impl) if con_reintentos else SincronizadorDispositivo(impl)
        valor = sincronizador.sincronizar(dispositivo, ultima)

        self.enviar_lectura_iot(id_dispositivo, valor)
        return valor

    def predecir_siguiente_valor(self, id_dispositivo: str, ventana: int = 3) -> Optional[float]:
        lecturas = self.lecturas_iot.get(id_dispositivo, [])
        if not lecturas:
            return None
        return round(mean(lecturas[-ventana:]), 2)

    # ---------- Catálogo de tipos de dispositivo (patrón Flyweight) ----------
    def ficha_tecnica(self, tipo: str) -> dict:
        """Ficha compartida del tipo (no se guarda copiada en cada dispositivo)."""
        return fabrica_fichas.obtener_ficha(tipo).to_dict()

    def catalogo_dispositivos(self) -> list[dict]:
        return [fabrica_fichas.obtener_ficha(t).to_dict() for t in fabrica_fichas.tipos_disponibles]
